<h1>Agulia Jobs Board</h1>
<p>Job Portal With PHP</p>
<br>	
<img src="https://i.imgur.com/Nkdvpnh.png">

<br>	

<img src="https://i.imgur.com/cfQ4trl.jpg">

<br>	

<img src="https://i.imgur.com/28fcjVb.png">

<br>	

<img src="https://i.imgur.com/DR3ZGkv.png">

<br>	

<img src="https://i.imgur.com/ognieQH.png">


<br>	

<img src="https://i.imgur.com/LQfUFpB.png">
