<footer class="main-footer" style="margin-left: 0px;">
    <div class="text-center">
        <strong>Copyright &copy; 2016-2017 <a href="learningfromscratch.online">Agulia</a>.</strong> All rights
        reserved.
    </div>
</footer>
<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>